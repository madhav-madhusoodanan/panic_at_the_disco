# How to use the code

<ol>
	<li /> Unzip the file
	<li /> Navigate into the file
	<li /> run `bash compile.sh` to compile the code
	<li /> run `bash run.sh` to run the code
</ol>


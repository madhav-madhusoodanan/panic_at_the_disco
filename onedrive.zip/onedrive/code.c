#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include "visualiser.c"


void display() {
    /* 
     * This function initiates a terminal session and runs the command.
     * It runs a python program that displays the relations between the nodes, graphically
     *  */
    plot("SampleInput.csv");
}

char* tokenizer(char* str) {
    const int len = strlen(str);
    int i = 0;
    for (i = 0; i < len; i++)
    {
        if (str[i] == ',' || str[i] == '\n' || str[i] == ' ')
        {
            str[i] = '\0';
            break;
        }

    }
    char* returned = str;
    str = str + i + 1;
    return returned;
}


unsigned int count(char* file) {
    /* 
     * Just counting the number of websites will be taking into consideration
     * I'll simply count the number of lines, subtract 1 and return
     * ( because the 1st line displays the list of the websites, 
     * while the rest of the lines shows the links of each of the websites)
     * 
     *  */

    unsigned int count = 0;
    char dummy[100];
    FILE *fp = fopen(file, "r");

    while (fscanf(fp, "%s", dummy) == 1){
        count += 1;
    }

    return (count - 1);
}

unsigned int integerify(char number[]) {
    /* This function returns 0 if the string passed is "0", else it returns 1 */
    return number[0] == '0' ? 0 : 1;
}

char stringify(int number){
    /* does the exact opposite of integerify */
    return number == 1 ? '1' : '0';
}


int is_anti_symmetric(unsigned int* links, unsigned int side){
    for(int i = 0; i < side; i++) {
        for(int j = i + 1; j < side; j++) {
            if(links[(i * side) + j] == 1 && links [(j * side) + i] == 1) {
                return 0;
            }
        }
    }
    return 1;
}

int is_symmetric(unsigned int* links, unsigned int side) {
    /* 
     * Symmetric matrices means a matrix whose transpose will equal itself.
     * the speciality of this matrix is that it is possible to go to the previous website from the current website
     * in one go.
     * 
     * For a minimum add, we must make it symmetric.
     * 
     *  */

    for(int i = 0; i < side; i++) {
        for(int j = i + 1; j < side; j++) {
            if(links[(i * side) + j] != links [(j * side) + i]) {
                return 0;
            }
        }
    }
    return 1;
}

int is_reflexive(unsigned int* links, unsigned int side) {
    /* 
     *  Self linking websites are those websites which have a link to itself
     *  This is represented by having a "1" on the diagonal, at the coordinates that correspond to the 
     *  index of the website.
     * 
     *  For a minimum add, we only have to replace a "0" with a "1" at any point in the diagonal.
     */

    for (int i = 0; i < side; i++)
    {
        if(links[(side + 1) * i] == 0) {
            return 0;
        }
    }
    return 1;
    
}

int* reachable_from_all(unsigned int* links, unsigned int side){
    /* returns an array, 1 for websites which can be reached from all, and 0 for those which can't */
    int websites[side];

    for (int i = 0; i < side; i++)
    {
        websites[i] = 1;
    }
    

    for(int i=0; i < side; i++){
        /* i is the index of the destination we are gonna check */

        for(int j=0; j < side; j++){
            /* the looping */
            if(links[side * j + i] != 1) {
                websites[i] = 0;
                break;
            }
        }

    }

    return websites;
}

int* reachable_to_all(unsigned int* links, unsigned int side){
    /* returns an array, 1 for websites which can be reached from all, and 0 for those which can't */
    int websites[side];

    for (int i = 0; i < side; i++)
    {
        websites[i] = 1;
    }
    

    for(int i=0; i < side; i++){
        /* i is the index of the source we are gonna check */

        for(int j=0; j < side; j++){
            /* the looping */
            if(links[j] != 1) {
                websites[i] = 0;
                break;
            }
        }

    }

    return websites;
}

int* self_centred_websites_from(unsigned int* links, unsigned int side){
    int websites[side];

    for (int i = 0; i < side; i++)
    {
        websites[i] = 1;
    }
    

    for(int i=0; i < side; i++){
        /* i is the index of the source we are gonna check */

        for(int j=0; j < side; j++){
            /* the looping */
            if(i != j && links[i * side + j] == 1) {
                websites[j] = 0;
                break;
            }
            if(i == j && links[i * side + j] == 0){
                websites[j] = 0;
                break;
            }
        }

    }

    return websites;
}

int* self_centred_websites_to(unsigned int* links, unsigned int side){
    int websites[side];

    for (int i = 0; i < side; i++)
    {
        websites[i] = 1;
    }
    

    for(int i=0; i < side; i++){
        /* i is the index of the source we are gonna check */

        for(int j=0; j < side; j++){
            /* the looping */
            if(i != j && links[i * side + j] == 1) {
                websites[i] = 0;
                break;
            }
            if(i == j && links[i * side + j] == 0){
                websites[i] = 0;
                break;
            }
        }

    }

    return websites;
}

void convert_to_csv(char* websites[], unsigned int* links, unsigned int website_count, char* filename){
    char websites_final[1024];
    
    for (int i = 0; i < website_count; i++)
    {
        strcat(websites_final, ",");
        strcat(websites_final, websites[i]);
    }
    strcat(websites_final, "\n");
    /* output to csv file */

    websites_final[0] = '\0';
    for (int i = 0; i < website_count; i++)
    {
        strcat(websites_final, websites[i]);
        for(int j = 0; j < website_count; i++)
        {
            strcat(websites_final, ",");
            char number[] = {stringify(links[i * website_count + j])};
            strcat(websites_final, number);
        }
        /* output to csv file */
    }
    
}

void extract(char* websites[], unsigned int* links, char* file) {
    /* This function tries to extract the relation matrix from the csv file */

    FILE* fp;
    char file_name[25];
    char input[100];

    unsigned int website_count = count(file);
    unsigned int i = 0;

    fp = fopen(file, "r");

    /* Extract the very first line, the list of all websites */
    fscanf(fp, "%s", input);

    /* Go in a loop and extract all the data from each line */
    for(int i = 0; i < website_count; i++) {

        fscanf(fp, "%s", input);
        websites[i] = tokenizer(input);

        for (int j = 0; j < website_count; j++){
            links[i*website_count + j] = integerify(tokenizer(input));
        }
        
    }
}

void print_website_names(char* names[], int* websites, unsigned int side
)

int print_main_menu() {
    printf("1. Does every website has a link to itself?\n");
    printf("2. Is it possible to always return back to the previous website from the current website in one step?\n");
    printf("3. Does every website has all th links to the websites which are reachable from it?\n");
    printf("4. Does there exist any website that contains a link to itself?\n");
    printf("5. Is it impossible to return to the previous website from the current website in one step?\n");
    printf("6. Is it impossible to return to the previous website from the current website in one step (excluding the cases where the current and previous website is the same)?\n");
    printf("7. Is it possible to divide the network into multiple pieces such that every website in a piece is reachable from every other website in that place?\n");
    printf("8. Is this relation an example of poset?\n");
    printf("9. Exit\n");

    printf("\n> ");
    
    int option;
    scanf("%d", &option);
    return option;
}

int print_menu_2() {
    char input = ' ';

    printf("Do you want to visualise how the network will look if we add minimum links to satisfy the property? [y/n]\n");
    printf("\n> ");
    scanf("%c", &input);

    if (input == 'n') return 0;
    else return 1;
}

int print_menu_3() {
    char input = ' ';

    printf("Do you want to know the nodes in each piece? [y/n]\n");
    printf("\n> ");
    scanf("%c", &input);

    if (input == 'n') return 0;
    else return 1;
}

int print_menu_4() {
    printf("1. Display the hasse diagram\n");
    printf("2. Display the website whose link is avaliable in every website\n");
    printf("3. Display the website which has links of every website\n");
    printf("4. Display the websites that do not have links to any other website except itself\n");
    printf("5. Display the websites which can't be reached from any other website except itself\n");
    printf("6. Given some websites, display the websites which are reachable from all of them\n");  /* User input enter krna pdega */
    printf("7. Given some websites, display the websites from which you can reach all those websites\n");
    printf("8. Is this relation an example of lattice?\n");
    printf("9. Return to main menu\n");

    printf("\n> ");

    int option;
    scanf("%d", &option);
    return option;
}



int menu_4_handler(char* names[], unsigned int* links, unsigned int side){

    int option;
    option = print_menu_4();

    while(option > 0 && option < 9){
        switch(option){
            case 1:
                /* display the hasse diagram */
                break;

            case 2:
                int* websites = reachable_from_all(links, side);
                for(int i = 0; i < side; i++){
                    if(websites[i] == 1){
                        printf("%s\n", names[i]);
                    }
                }
                break;

            case 3:
                int* websites = reachable_to_all(links, side);
                for(int i = 0; i < side; i++){
                    if(websites[i] == 1){
                        printf("%s\n", names[i]);
                    }
                }
                break;


            case 4:
                int* websites = self_centred_websites_to(links, side);
                for(int i = 0; i < side; i++){
                    if(websites[i] == 1){
                        printf("%s\n", names[i]);
                    }
                }
                break;

            case 5:
                break;

            case 6:
                break;

            case 7:
                break;

            case 8:
                break;
        }
    }

}

void convert_to_hasse(unsigned int* links){
    /* remove self links */
    /* remove transitive relations */
    /* ask sir for how to plot hasse */
}

int print_menu_5() {
    printf("1. Given two websites A and B, display the website which is reachable by both A and B and can also reach to all such websites that both A and B can reach.\n");
    printf("2. Given two websites A and B, display the website which can reach to both A and B and is also reachable from all such websites that can reach to both A and B\n");
    printf("3. is the lattice distributable?\n");
    printf("4. Return to menu 4\n");

    printf("\n> ");

    int option;
    scanf("%d", &option);
    return option;
}

int menu_5_handler(){}

int main() {
    int option = 0;

    unsigned int website_count = count("SampleInput.csv");
    char* websites[website_count];
    unsigned int links[website_count * website_count];
    extract(websites, links, "SampleInput.csv");
    
    option = print_main_menu();
    while (option > 0 && option < 9) {
        switch (option)
        {
        case 1:
            if (is_reflexive(links, website_count) == 0) {
                printf("NO\n");
                if (print_menu_2()) {} else {}
            } else {
                printf("YES\n");
            }
            break;
        
        case 2:
            if (is_symmetric(links, website_count) == 0)
            {
                printf("NO\n");
                if(print_menu_2()) {} else {}
            } else {
                printf("YES\n");
            }
            break;

        case 3: 
            display();
            exit(0);

        case 8:
            break;

        case 9:
            exit(0);
            break;
            
        
        default:
            break;
        }
        option = print_main_menu();
    }
}

/* 

* * * * * * *
* * * * * * *
* * * * * * *
* * * * * * *
* * * * * * *

 */

/* TODO:

1. finish up menu 4 */

/* HARD THINGS
1. lattice
2. hasse diagrams */